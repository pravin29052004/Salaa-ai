# Sala AI Assistant

Voice + text AI assistant app with GitHub APK builder.